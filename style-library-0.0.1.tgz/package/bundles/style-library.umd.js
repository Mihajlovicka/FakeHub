(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common/http'), require('rxjs'), require('rxjs/operators'), require('@angular/common')) :
  typeof define === 'function' && define.amd ? define('style-library', ['exports', '@angular/core', '@angular/common/http', 'rxjs', 'rxjs/operators', '@angular/common'], factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global["style-library"] = {}, global.ng.core, global.ng.common.http, global.rxjs, global.rxjs.operators, global.ng.common));
})(this, (function (exports, i0, i1, rxjs, operators, i3) { 'use strict';

  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = Object.create(null);
    if (e) {
      Object.keys(e).forEach(function (k) {
        if (k !== 'default') {
          var d = Object.getOwnPropertyDescriptor(e, k);
          Object.defineProperty(n, k, d.get ? d : {
            enumerable: true,
            get: function () { return e[k]; }
          });
        }
      });
    }
    n["default"] = e;
    return Object.freeze(n);
  }

  var i0__namespace = /*#__PURE__*/_interopNamespace(i0);
  var i1__namespace = /*#__PURE__*/_interopNamespace(i1);
  var i3__namespace = /*#__PURE__*/_interopNamespace(i3);

  /******************************************************************************
  Copyright (c) Microsoft Corporation.

  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** */
  /* global Reflect, Promise, SuppressedError, Symbol, Iterator */
  var extendStatics = function (d, b) {
      extendStatics = Object.setPrototypeOf ||
          ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
          function (d, b) { for (var p in b)
              if (Object.prototype.hasOwnProperty.call(b, p))
                  d[p] = b[p]; };
      return extendStatics(d, b);
  };
  function __extends(d, b) {
      if (typeof b !== "function" && b !== null)
          throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
      extendStatics(d, b);
      function __() { this.constructor = d; }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  }
  var __assign = function () {
      __assign = Object.assign || function __assign(t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
              s = arguments[i];
              for (var p in s)
                  if (Object.prototype.hasOwnProperty.call(s, p))
                      t[p] = s[p];
          }
          return t;
      };
      return __assign.apply(this, arguments);
  };
  function __rest(s, e) {
      var t = {};
      for (var p in s)
          if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
              t[p] = s[p];
      if (s != null && typeof Object.getOwnPropertySymbols === "function")
          for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
              if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                  t[p[i]] = s[p[i]];
          }
      return t;
  }
  function __decorate(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
          r = Reflect.decorate(decorators, target, key, desc);
      else
          for (var i = decorators.length - 1; i >= 0; i--)
              if (d = decorators[i])
                  r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
  }
  function __param(paramIndex, decorator) {
      return function (target, key) { decorator(target, key, paramIndex); };
  }
  function __esDecorate(ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
      function accept(f) { if (f !== void 0 && typeof f !== "function")
          throw new TypeError("Function expected"); return f; }
      var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
      var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
      var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
      var _, done = false;
      for (var i = decorators.length - 1; i >= 0; i--) {
          var context = {};
          for (var p in contextIn)
              context[p] = p === "access" ? {} : contextIn[p];
          for (var p in contextIn.access)
              context.access[p] = contextIn.access[p];
          context.addInitializer = function (f) { if (done)
              throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
          var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
          if (kind === "accessor") {
              if (result === void 0)
                  continue;
              if (result === null || typeof result !== "object")
                  throw new TypeError("Object expected");
              if (_ = accept(result.get))
                  descriptor.get = _;
              if (_ = accept(result.set))
                  descriptor.set = _;
              if (_ = accept(result.init))
                  initializers.unshift(_);
          }
          else if (_ = accept(result)) {
              if (kind === "field")
                  initializers.unshift(_);
              else
                  descriptor[key] = _;
          }
      }
      if (target)
          Object.defineProperty(target, contextIn.name, descriptor);
      done = true;
  }
  ;
  function __runInitializers(thisArg, initializers, value) {
      var useValue = arguments.length > 2;
      for (var i = 0; i < initializers.length; i++) {
          value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
      }
      return useValue ? value : void 0;
  }
  ;
  function __propKey(x) {
      return typeof x === "symbol" ? x : "".concat(x);
  }
  ;
  function __setFunctionName(f, name, prefix) {
      if (typeof name === "symbol")
          name = name.description ? "[".concat(name.description, "]") : "";
      return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
  }
  ;
  function __metadata(metadataKey, metadataValue) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
          return Reflect.metadata(metadataKey, metadataValue);
  }
  function __awaiter(thisArg, _arguments, P, generator) {
      function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
      return new (P || (P = Promise))(function (resolve, reject) {
          function fulfilled(value) { try {
              step(generator.next(value));
          }
          catch (e) {
              reject(e);
          } }
          function rejected(value) { try {
              step(generator["throw"](value));
          }
          catch (e) {
              reject(e);
          } }
          function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
          step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
  }
  function __generator(thisArg, body) {
      var _ = { label: 0, sent: function () { if (t[0] & 1)
              throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
      return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
      function verb(n) { return function (v) { return step([n, v]); }; }
      function step(op) {
          if (f)
              throw new TypeError("Generator is already executing.");
          while (g && (g = 0, op[0] && (_ = 0)), _)
              try {
                  if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                      return t;
                  if (y = 0, t)
                      op = [op[0] & 2, t.value];
                  switch (op[0]) {
                      case 0:
                      case 1:
                          t = op;
                          break;
                      case 4:
                          _.label++;
                          return { value: op[1], done: false };
                      case 5:
                          _.label++;
                          y = op[1];
                          op = [0];
                          continue;
                      case 7:
                          op = _.ops.pop();
                          _.trys.pop();
                          continue;
                      default:
                          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                              _ = 0;
                              continue;
                          }
                          if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                              _.label = op[1];
                              break;
                          }
                          if (op[0] === 6 && _.label < t[1]) {
                              _.label = t[1];
                              t = op;
                              break;
                          }
                          if (t && _.label < t[2]) {
                              _.label = t[2];
                              _.ops.push(op);
                              break;
                          }
                          if (t[2])
                              _.ops.pop();
                          _.trys.pop();
                          continue;
                  }
                  op = body.call(thisArg, _);
              }
              catch (e) {
                  op = [6, e];
                  y = 0;
              }
              finally {
                  f = t = 0;
              }
          if (op[0] & 5)
              throw op[1];
          return { value: op[0] ? op[1] : void 0, done: true };
      }
  }
  var __createBinding = Object.create ? (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function () { return m[k]; } };
      }
      Object.defineProperty(o, k2, desc);
  }) : (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      o[k2] = m[k];
  });
  function __exportStar(m, o) {
      for (var p in m)
          if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
              __createBinding(o, m, p);
  }
  function __values(o) {
      var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
      if (m)
          return m.call(o);
      if (o && typeof o.length === "number")
          return {
              next: function () {
                  if (o && i >= o.length)
                      o = void 0;
                  return { value: o && o[i++], done: !o };
              }
          };
      throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
  }
  function __read(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m)
          return o;
      var i = m.call(o), r, ar = [], e;
      try {
          while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
              ar.push(r.value);
      }
      catch (error) {
          e = { error: error };
      }
      finally {
          try {
              if (r && !r.done && (m = i["return"]))
                  m.call(i);
          }
          finally {
              if (e)
                  throw e.error;
          }
      }
      return ar;
  }
  /** @deprecated */
  function __spread() {
      for (var ar = [], i = 0; i < arguments.length; i++)
          ar = ar.concat(__read(arguments[i]));
      return ar;
  }
  /** @deprecated */
  function __spreadArrays() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++)
          s += arguments[i].length;
      for (var r = Array(s), k = 0, i = 0; i < il; i++)
          for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
              r[k] = a[j];
      return r;
  }
  function __spreadArray(to, from, pack) {
      if (pack || arguments.length === 2)
          for (var i = 0, l = from.length, ar; i < l; i++) {
              if (ar || !(i in from)) {
                  if (!ar)
                      ar = Array.prototype.slice.call(from, 0, i);
                  ar[i] = from[i];
              }
          }
      return to.concat(ar || Array.prototype.slice.call(from));
  }
  function __await(v) {
      return this instanceof __await ? (this.v = v, this) : new __await(v);
  }
  function __asyncGenerator(thisArg, _arguments, generator) {
      if (!Symbol.asyncIterator)
          throw new TypeError("Symbol.asyncIterator is not defined.");
      var g = generator.apply(thisArg, _arguments || []), i, q = [];
      return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function () { return this; }, i;
      function awaitReturn(f) { return function (v) { return Promise.resolve(v).then(f, reject); }; }
      function verb(n, f) { if (g[n]) {
          i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); };
          if (f)
              i[n] = f(i[n]);
      } }
      function resume(n, v) { try {
          step(g[n](v));
      }
      catch (e) {
          settle(q[0][3], e);
      } }
      function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
      function fulfill(value) { resume("next", value); }
      function reject(value) { resume("throw", value); }
      function settle(f, v) { if (f(v), q.shift(), q.length)
          resume(q[0][0], q[0][1]); }
  }
  function __asyncDelegator(o) {
      var i, p;
      return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
      function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: false } : f ? f(v) : v; } : f; }
  }
  function __asyncValues(o) {
      if (!Symbol.asyncIterator)
          throw new TypeError("Symbol.asyncIterator is not defined.");
      var m = o[Symbol.asyncIterator], i;
      return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
      function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
      function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
  }
  function __makeTemplateObject(cooked, raw) {
      if (Object.defineProperty) {
          Object.defineProperty(cooked, "raw", { value: raw });
      }
      else {
          cooked.raw = raw;
      }
      return cooked;
  }
  ;
  var __setModuleDefault = Object.create ? (function (o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
  }) : function (o, v) {
      o["default"] = v;
  };
  var ownKeys = function (o) {
      ownKeys = Object.getOwnPropertyNames || function (o) {
          var ar = [];
          for (var k in o)
              if (Object.prototype.hasOwnProperty.call(o, k))
                  ar[ar.length] = k;
          return ar;
      };
      return ownKeys(o);
  };
  function __importStar(mod) {
      if (mod && mod.__esModule)
          return mod;
      var result = {};
      if (mod != null)
          for (var k = ownKeys(mod), i = 0; i < k.length; i++)
              if (k[i] !== "default")
                  __createBinding(result, mod, k[i]);
      __setModuleDefault(result, mod);
      return result;
  }
  function __importDefault(mod) {
      return (mod && mod.__esModule) ? mod : { default: mod };
  }
  function __classPrivateFieldGet(receiver, state, kind, f) {
      if (kind === "a" && !f)
          throw new TypeError("Private accessor was defined without a getter");
      if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
          throw new TypeError("Cannot read private member from an object whose class did not declare it");
      return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
  }
  function __classPrivateFieldSet(receiver, state, value, kind, f) {
      if (kind === "m")
          throw new TypeError("Private method is not writable");
      if (kind === "a" && !f)
          throw new TypeError("Private accessor was defined without a setter");
      if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
          throw new TypeError("Cannot write private member to an object whose class did not declare it");
      return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
  }
  function __classPrivateFieldIn(state, receiver) {
      if (receiver === null || (typeof receiver !== "object" && typeof receiver !== "function"))
          throw new TypeError("Cannot use 'in' operator on non-object");
      return typeof state === "function" ? receiver === state : state.has(receiver);
  }
  function __addDisposableResource(env, value, async) {
      if (value !== null && value !== void 0) {
          if (typeof value !== "object" && typeof value !== "function")
              throw new TypeError("Object expected.");
          var dispose, inner;
          if (async) {
              if (!Symbol.asyncDispose)
                  throw new TypeError("Symbol.asyncDispose is not defined.");
              dispose = value[Symbol.asyncDispose];
          }
          if (dispose === void 0) {
              if (!Symbol.dispose)
                  throw new TypeError("Symbol.dispose is not defined.");
              dispose = value[Symbol.dispose];
              if (async)
                  inner = dispose;
          }
          if (typeof dispose !== "function")
              throw new TypeError("Object not disposable.");
          if (inner)
              dispose = function () { try {
                  inner.call(this);
              }
              catch (e) {
                  return Promise.reject(e);
              } };
          env.stack.push({ value: value, dispose: dispose, async: async });
      }
      else if (async) {
          env.stack.push({ async: true });
      }
      return value;
  }
  var _SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
      var e = new Error(message);
      return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
  };
  function __disposeResources(env) {
      function fail(e) {
          env.error = env.hasError ? new _SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
          env.hasError = true;
      }
      var r, s = 0;
      function next() {
          while (r = env.stack.pop()) {
              try {
                  if (!r.async && s === 1)
                      return s = 0, env.stack.push(r), Promise.resolve().then(next);
                  if (r.dispose) {
                      var result = r.dispose.call(r.value);
                      if (r.async)
                          return s |= 2, Promise.resolve(result).then(next, function (e) { fail(e); return next(); });
                  }
                  else
                      s |= 1;
              }
              catch (e) {
                  fail(e);
              }
          }
          if (s === 1)
              return env.hasError ? Promise.reject(env.error) : Promise.resolve();
          if (env.hasError)
              throw env.error;
      }
      return next();
  }
  function __rewriteRelativeImportExtension(path, preserveJsx) {
      if (typeof path === "string" && /^\.\.?\//.test(path)) {
          return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
              return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
          });
      }
      return path;
  }
  var tslib_es6 = {
      __extends: __extends,
      __assign: __assign,
      __rest: __rest,
      __decorate: __decorate,
      __param: __param,
      __esDecorate: __esDecorate,
      __runInitializers: __runInitializers,
      __propKey: __propKey,
      __setFunctionName: __setFunctionName,
      __metadata: __metadata,
      __awaiter: __awaiter,
      __generator: __generator,
      __createBinding: __createBinding,
      __exportStar: __exportStar,
      __values: __values,
      __read: __read,
      __spread: __spread,
      __spreadArrays: __spreadArrays,
      __spreadArray: __spreadArray,
      __await: __await,
      __asyncGenerator: __asyncGenerator,
      __asyncDelegator: __asyncDelegator,
      __asyncValues: __asyncValues,
      __makeTemplateObject: __makeTemplateObject,
      __importStar: __importStar,
      __importDefault: __importDefault,
      __classPrivateFieldGet: __classPrivateFieldGet,
      __classPrivateFieldSet: __classPrivateFieldSet,
      __classPrivateFieldIn: __classPrivateFieldIn,
      __addDisposableResource: __addDisposableResource,
      __disposeResources: __disposeResources,
      __rewriteRelativeImportExtension: __rewriteRelativeImportExtension,
  };

  var DesignComponentsService = /** @class */ (function () {
      function DesignComponentsService(http, config) {
          var _a;
          this.http = http;
          this.httpHeaders = new i1.HttpHeaders();
          this.componentsSubject = new rxjs.BehaviorSubject(null);
          this.colors$ = this.componentsSubject.asObservable();
          this.currentComponents = null;
          this.serverUrl = (_a = config === null || config === void 0 ? void 0 : config.serverUrl) !== null && _a !== void 0 ? _a : '';
          this.httpHeaders = new i1.HttpHeaders();
          this.httpHeaders = this.httpHeaders.set('Content-Type', 'application/json');
      }
      DesignComponentsService.prototype.loadComponents = function () {
          var _this = this;
          var url = this.serverUrl + '/design/component/all';
          return this.http.get(url, { headers: this.httpHeaders }).pipe(operators.tap(function (colors) {
              _this.currentComponents = colors;
              _this.componentsSubject.next(colors);
              _this.initializeDesignComponentSections();
          }));
      };
      DesignComponentsService.prototype.initializeDesignComponentSections = function () {
          var _this = this;
          if (this.currentComponents && this.currentComponents.length > 0) {
              var back = this.currentComponents.find(function (global) { return global.code == 'body-background'; });
              var backCard = this.currentComponents.find(function (global) { return global.code == 'card-body-background'; });
              var bt = this.currentComponents.find(function (global) { return global.code == 'bar-top'; });
              var bb = this.currentComponents.find(function (global) { return global.code == 'bar-bottom'; });
              var bsl = this.currentComponents.find(function (global) { return global.code == 'bar-side-lett'; });
              var bsr = this.currentComponents.find(function (global) { return global.code == 'bar-side-right'; });
              var globalArray = [back, backCard, bt, bb, bsl, bsr];
              globalArray.forEach(function (elem) {
                  var e_1, _b;
                  if (elem === null || elem === void 0 ? void 0 : elem.cssConfig) {
                      var enteries = Object.entries(elem === null || elem === void 0 ? void 0 : elem.cssConfig);
                      try {
                          for (var enteries_1 = __values(enteries), enteries_1_1 = enteries_1.next(); !enteries_1_1.done; enteries_1_1 = enteries_1.next()) {
                              var _c = __read(enteries_1_1.value, 2), key = _c[0], value = _c[1];
                              _this.applyColor(key, value);
                          }
                      }
                      catch (e_1_1) { e_1 = { error: e_1_1 }; }
                      finally {
                          try {
                              if (enteries_1_1 && !enteries_1_1.done && (_b = enteries_1.return)) _b.call(enteries_1);
                          }
                          finally { if (e_1) throw e_1.error; }
                      }
                  }
                  if ((elem === null || elem === void 0 ? void 0 : elem.code) == 'body-background' && (elem === null || elem === void 0 ? void 0 : elem.designColor) && (elem === null || elem === void 0 ? void 0 : elem.designColor.fill)) {
                      _this.applyColor('--global-background-color', elem === null || elem === void 0 ? void 0 : elem.designColor.fill);
                  }
                  if ((elem === null || elem === void 0 ? void 0 : elem.code) == 'card-body-background' && (elem === null || elem === void 0 ? void 0 : elem.designColor) && (elem === null || elem === void 0 ? void 0 : elem.designColor.fill)) {
                      _this.applyColor('--global-card-background-color', elem === null || elem === void 0 ? void 0 : elem.designColor.fill);
                  }
                  if ((elem === null || elem === void 0 ? void 0 : elem.code) == 'bar-top' && (elem === null || elem === void 0 ? void 0 : elem.designColor)) {
                      _this.applyColor('--content-heading-bg', elem === null || elem === void 0 ? void 0 : elem.designColor.fill);
                      _this.applyColor('--content-heading-border', elem === null || elem === void 0 ? void 0 : elem.designColor.border);
                      _this.applyColor('--content-heading-color', elem === null || elem === void 0 ? void 0 : elem.designColor.text);
                  }
                  if ((elem === null || elem === void 0 ? void 0 : elem.code) == 'bar-bottom' && (elem === null || elem === void 0 ? void 0 : elem.designColor)) {
                      _this.applyColor('--content-footer-bg', elem === null || elem === void 0 ? void 0 : elem.designColor.fill);
                      _this.applyColor('--content-footer-border', elem === null || elem === void 0 ? void 0 : elem.designColor.border);
                      _this.applyColor('--content-footer-color', elem === null || elem === void 0 ? void 0 : elem.designColor.text);
                  }
                  if ((elem === null || elem === void 0 ? void 0 : elem.code) == 'bar-side-lett' && (elem === null || elem === void 0 ? void 0 : elem.designColor)) {
                      _this.applyColor('--content-side-bg', elem === null || elem === void 0 ? void 0 : elem.designColor.fill);
                      _this.applyColor('--content-side-border', elem === null || elem === void 0 ? void 0 : elem.designColor.border);
                      _this.applyColor('--content-side-color', elem === null || elem === void 0 ? void 0 : elem.designColor.text);
                  }
              });
          }
      };
      DesignComponentsService.prototype.applyColor = function (variable, value) {
          document.documentElement.style.setProperty(variable, value);
      };
      return DesignComponentsService;
  }());
  DesignComponentsService.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: DesignComponentsService, deps: [{ token: i1__namespace.HttpClient }, { token: 'STYLE_LIBRARY_CONFIG', optional: true }], target: i0__namespace.ɵɵFactoryTarget.Injectable });
  DesignComponentsService.ɵprov = i0__namespace.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: DesignComponentsService });
  i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: DesignComponentsService, decorators: [{
              type: i0.Injectable
          }], ctorParameters: function () {
          return [{ type: i1__namespace.HttpClient }, { type: undefined, decorators: [{
                          type: i0.Optional
                      }, {
                          type: i0.Inject,
                          args: ['STYLE_LIBRARY_CONFIG']
                      }] }];
      } });

  var ButtonComponent = /** @class */ (function () {
      function ButtonComponent(http, componentsService, el) {
          this.http = http;
          this.componentsService = componentsService;
          this.el = el;
          this.code = '';
          this.color = '';
          this.label = '';
          this.iconPosition = '';
          this.selected = false;
          this.iconExists = false;
          this.hover = false;
          this.hasProjectedContent = false;
          this.currentComponent = undefined;
      }
      ButtonComponent.prototype.ngOnInit = function () {
          var _this = this;
          var _a;
          if (!this.code) {
              console.error('ButtonComponent: code field is required.');
              return;
          }
          var components = this.componentsService.currentComponents;
          this.currentComponent = components === null || components === void 0 ? void 0 : components.find(function (c) { return c.code === _this.code; });
          this.iconExists = !!(this.currentComponent && this.currentComponent.designIcon);
          this.iconPosition = ((_a = this.currentComponent) === null || _a === void 0 ? void 0 : _a.iconPosition) || '';
          console.log('all components:', components);
          console.log('currentComponent: ', this.currentComponent);
          if (!this.currentComponent) {
              console.warn('ButtonComponent: component for code "' + this.code + '" not found.');
              return;
          }
      };
      ButtonComponent.prototype.ngAfterContentInit = function () {
          var projected = this.el.nativeElement.textContent
              ? this.el.nativeElement.textContent.trim()
              : '';
          this.hasProjectedContent = !!projected;
      };
      Object.defineProperty(ButtonComponent.prototype, "iconPath", {
          get: function () {
              return this.currentComponent && this.currentComponent.designIcon
                  ? this.componentsService.serverUrl +
                      '/design/icon/image?uuid=' +
                      this.currentComponent.designIcon.uuid
                  : '';
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(ButtonComponent.prototype, "buttonStyles", {
          get: function () {
              var designColor = this.currentComponent
                  ? this.currentComponent.designColor
                  : undefined;
              var borderRadius = 'var(--global-border-radius, 3px)';
              var borderWidth = '1px';
              var fontSize = '';
              var fontFamily = '';
              if (this.currentComponent && this.currentComponent.cssConfig) {
                  var cssConfig = Object.entries(this.currentComponent.cssConfig);
                  borderRadius =
                      this.currentComponent.cssConfig['--btn-border-radius'] || borderRadius;
                  borderWidth =
                      this.currentComponent.cssConfig['--btn-border-width'] || borderWidth;
                  fontSize =
                      this.currentComponent.cssConfig['--btn-font-size'] || borderWidth;
                  fontFamily =
                      this.currentComponent.cssConfig['--btn-font-family'] || borderWidth;
              }
              if (this.selected) {
                  return {
                      'border-radius': borderRadius,
                      'border-width': borderWidth,
                      'font-size': fontSize,
                      'font-family': fontFamily,
                      'background-color': designColor ? designColor.fillSelected || '' : '',
                      'border-color': designColor ? designColor.borderSelected || '' : '',
                      color: designColor ? designColor.textSelected || '' : '',
                  };
              }
              if (this.hover) {
                  return {
                      'border-radius': borderRadius,
                      'border-width': borderWidth,
                      'font-size': fontSize,
                      'font-family': fontFamily,
                      'background-color': designColor ? designColor.fillHover || '' : '',
                      'border-color': designColor ? designColor.borderHover || '' : '',
                      color: designColor ? designColor.textHover || '' : '',
                  };
              }
              return {
                  'border-radius': borderRadius,
                  'border-width': borderWidth,
                  'font-size': fontSize,
                  'font-family': fontFamily,
                  'background-color': designColor ? designColor.fill || '' : '',
                  'border-color': designColor ? designColor.border || '' : '',
                  color: designColor ? designColor.text || '' : '',
              };
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(ButtonComponent.prototype, "iconWrapperStyles", {
          get: function () {
              var designColor = this.currentComponent
                  ? this.currentComponent.designColor
                  : undefined;
              var borderRadius = 'var(--global-border-radius, 3px)';
              if (this.currentComponent && this.currentComponent.cssConfig) {
                  var cssConfig = Object.entries(this.currentComponent.cssConfig);
                  borderRadius =
                      this.currentComponent.cssConfig['--btn-border-radius'] || borderRadius;
              }
              return {
                  'background-color': designColor ? designColor.fillHover || '' : '',
                  'border-color': designColor ? designColor.borderHover || '' : '',
                  color: designColor ? designColor.textHover || '' : '',
                  display: 'inline-flex',
                  'align-items': 'center',
                  'justify-content': 'center',
                  'border-radius': borderRadius,
                  'margin-right': this.iconPosition === 'left' ? '0px' : '0',
                  'margin-left': this.iconPosition === 'right' ? '0px' : '0',
                  padding: '4px',
              };
          },
          enumerable: false,
          configurable: true
      });
      return ButtonComponent;
  }());
  ButtonComponent.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: ButtonComponent, deps: [{ token: i1__namespace.HttpClient }, { token: DesignComponentsService }, { token: i0__namespace.ElementRef }], target: i0__namespace.ɵɵFactoryTarget.Component });
  ButtonComponent.ɵcmp = i0__namespace.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.0.5", type: ButtonComponent, selector: "style-library-button", inputs: { code: "code" }, ngImport: i0__namespace, template: "<button\r\n  type=\"button\"\r\n  class=\"btn-bsi\"\r\n  [ngStyle]=\"buttonStyles\"\r\n  (mouseenter)=\"hover = true\"\r\n  (mouseleave)=\"hover = false\"\r\n>\r\n  <ng-container *ngIf=\"iconExists && iconPosition === 'left'\">\r\n    <span class=\"btn-icon-wrapper\" [ngStyle]=\"iconWrapperStyles\">\r\n      <img [src]=\"iconPath\" class=\"btn-icon\" />\r\n    </span>\r\n  </ng-container>\r\n\r\n  <span [ngClass]=\"[(iconPosition == 'left')?'mr-2':'', (iconPosition == 'right')?'ml-1':'', (iconPosition == null)?'mr-1 ml-1':'']\" class=\"\">\r\n    <ng-content></ng-content>\r\n    <ng-container *ngIf=\"!hasProjectedContent && label\">\r\n      {{ label }}\r\n    </ng-container>\r\n  </span>\r\n\r\n  <ng-container *ngIf=\"iconExists && iconPosition === 'right'\">\r\n    <span class=\"btn-icon-wrapper\" [ngStyle]=\"iconWrapperStyles\">\r\n      <img [src]=\"iconPath\" class=\"btn-icon\" />\r\n    </span>\r\n  </ng-container>\r\n</button>", styles: [".btn-bsi{padding:0;display:inline-flex;align-items:center;vertical-align:top;grid-gap:.5rem;gap:.5rem;font-weight:500;cursor:pointer;transition:all .2s ease-in-out}.btn-bsi .btn-icon{display:block;width:16px;height:16px}\n"], directives: [{ type: i3__namespace.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { type: i3__namespace.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i3__namespace.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
  i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: ButtonComponent, decorators: [{
              type: i0.Component,
              args: [{
                      selector: 'style-library-button',
                      templateUrl: './button.component.html',
                      styleUrls: ['./button.component.scss'],
                  }]
          }], ctorParameters: function () { return [{ type: i1__namespace.HttpClient }, { type: DesignComponentsService }, { type: i0__namespace.ElementRef }]; }, propDecorators: { code: [{
                  type: i0.Input
              }] } });

  function loadComponentsFactory(componentsService) {
      return function () { return componentsService.loadComponents().toPromise(); };
  }
  var StyleLibraryModule = /** @class */ (function () {
      function StyleLibraryModule() {
      }
      StyleLibraryModule.forRoot = function (config) {
          return {
              ngModule: StyleLibraryModule,
              providers: [
                  { provide: 'STYLE_LIBRARY_CONFIG', useValue: config },
                  DesignComponentsService,
                  {
                      provide: i0.APP_INITIALIZER,
                      useFactory: loadComponentsFactory,
                      deps: [DesignComponentsService],
                      multi: true,
                  },
              ],
          };
      };
      StyleLibraryModule.forChild = function () {
          return {
              ngModule: StyleLibraryModule,
          };
      };
      return StyleLibraryModule;
  }());
  StyleLibraryModule.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: StyleLibraryModule, deps: [], target: i0__namespace.ɵɵFactoryTarget.NgModule });
  StyleLibraryModule.ɵmod = i0__namespace.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: StyleLibraryModule, declarations: [ButtonComponent], imports: [i3.CommonModule, i1.HttpClientModule], exports: [ButtonComponent] });
  StyleLibraryModule.ɵinj = i0__namespace.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: StyleLibraryModule, imports: [[i3.CommonModule, i1.HttpClientModule]] });
  i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: StyleLibraryModule, decorators: [{
              type: i0.NgModule,
              args: [{
                      declarations: [ButtonComponent],
                      imports: [i3.CommonModule, i1.HttpClientModule],
                      exports: [ButtonComponent],
                  }]
          }] });

  /**
   * Generated bundle index. Do not edit.
   */

  exports.ButtonComponent = ButtonComponent;
  exports.DesignComponentsService = DesignComponentsService;
  exports.StyleLibraryModule = StyleLibraryModule;
  exports.loadComponentsFactory = loadComponentsFactory;

  Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=style-library.umd.js.map
