import * as i0 from '@angular/core';
import { Injectable, Optional, Inject, Component, Input, APP_INITIALIZER, NgModule } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpHeaders, HttpClientModule } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';

class DesignComponentsService {
    constructor(http, config) {
        var _a;
        this.http = http;
        this.httpHeaders = new HttpHeaders();
        this.componentsSubject = new BehaviorSubject(null);
        this.colors$ = this.componentsSubject.asObservable();
        this.currentComponents = null;
        this.serverUrl = (_a = config === null || config === void 0 ? void 0 : config.serverUrl) !== null && _a !== void 0 ? _a : '';
        this.httpHeaders = new HttpHeaders();
        this.httpHeaders = this.httpHeaders.set('Content-Type', 'application/json');
    }
    loadComponents() {
        const url = this.serverUrl + '/design/component/all';
        return this.http.get(url, { headers: this.httpHeaders }).pipe(tap(colors => {
            this.currentComponents = colors;
            this.componentsSubject.next(colors);
            this.initializeDesignComponentSections();
        }));
    }
    initializeDesignComponentSections() {
        if (this.currentComponents && this.currentComponents.length > 0) {
            const back = this.currentComponents.find(global => global.code == 'body-background');
            const backCard = this.currentComponents.find(global => global.code == 'card-body-background');
            const bt = this.currentComponents.find(global => global.code == 'bar-top');
            const bb = this.currentComponents.find(global => global.code == 'bar-bottom');
            const bsl = this.currentComponents.find(global => global.code == 'bar-side-lett');
            const bsr = this.currentComponents.find(global => global.code == 'bar-side-right');
            const globalArray = [back, backCard, bt, bb, bsl, bsr];
            globalArray.forEach(elem => {
                if (elem === null || elem === void 0 ? void 0 : elem.cssConfig) {
                    const enteries = Object.entries(elem === null || elem === void 0 ? void 0 : elem.cssConfig);
                    for (const [key, value] of enteries) {
                        this.applyColor(key, value);
                    }
                }
                if ((elem === null || elem === void 0 ? void 0 : elem.code) == 'body-background' && (elem === null || elem === void 0 ? void 0 : elem.designColor) && (elem === null || elem === void 0 ? void 0 : elem.designColor.fill)) {
                    this.applyColor('--global-background-color', elem === null || elem === void 0 ? void 0 : elem.designColor.fill);
                }
                if ((elem === null || elem === void 0 ? void 0 : elem.code) == 'card-body-background' && (elem === null || elem === void 0 ? void 0 : elem.designColor) && (elem === null || elem === void 0 ? void 0 : elem.designColor.fill)) {
                    this.applyColor('--global-card-background-color', elem === null || elem === void 0 ? void 0 : elem.designColor.fill);
                }
                if ((elem === null || elem === void 0 ? void 0 : elem.code) == 'bar-top' && (elem === null || elem === void 0 ? void 0 : elem.designColor)) {
                    this.applyColor('--content-heading-bg', elem === null || elem === void 0 ? void 0 : elem.designColor.fill);
                    this.applyColor('--content-heading-border', elem === null || elem === void 0 ? void 0 : elem.designColor.border);
                    this.applyColor('--content-heading-color', elem === null || elem === void 0 ? void 0 : elem.designColor.text);
                }
                if ((elem === null || elem === void 0 ? void 0 : elem.code) == 'bar-bottom' && (elem === null || elem === void 0 ? void 0 : elem.designColor)) {
                    this.applyColor('--content-footer-bg', elem === null || elem === void 0 ? void 0 : elem.designColor.fill);
                    this.applyColor('--content-footer-border', elem === null || elem === void 0 ? void 0 : elem.designColor.border);
                    this.applyColor('--content-footer-color', elem === null || elem === void 0 ? void 0 : elem.designColor.text);
                }
                if ((elem === null || elem === void 0 ? void 0 : elem.code) == 'bar-side-lett' && (elem === null || elem === void 0 ? void 0 : elem.designColor)) {
                    this.applyColor('--content-side-bg', elem === null || elem === void 0 ? void 0 : elem.designColor.fill);
                    this.applyColor('--content-side-border', elem === null || elem === void 0 ? void 0 : elem.designColor.border);
                    this.applyColor('--content-side-color', elem === null || elem === void 0 ? void 0 : elem.designColor.text);
                }
            });
        }
    }
    applyColor(variable, value) {
        document.documentElement.style.setProperty(variable, value);
    }
}
DesignComponentsService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: DesignComponentsService, deps: [{ token: i1.HttpClient }, { token: 'STYLE_LIBRARY_CONFIG', optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
DesignComponentsService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: DesignComponentsService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: DesignComponentsService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: ['STYLE_LIBRARY_CONFIG']
                }] }]; } });

class ButtonComponent {
    constructor(http, componentsService, el) {
        this.http = http;
        this.componentsService = componentsService;
        this.el = el;
        this.code = '';
        this.color = '';
        this.label = '';
        this.iconPosition = '';
        this.selected = false;
        this.iconExists = false;
        this.hover = false;
        this.hasProjectedContent = false;
        this.currentComponent = undefined;
    }
    ngOnInit() {
        var _a;
        if (!this.code) {
            console.error('ButtonComponent: code field is required.');
            return;
        }
        const components = this.componentsService.currentComponents;
        this.currentComponent = components === null || components === void 0 ? void 0 : components.find((c) => c.code === this.code);
        this.iconExists = !!(this.currentComponent && this.currentComponent.designIcon);
        this.iconPosition = ((_a = this.currentComponent) === null || _a === void 0 ? void 0 : _a.iconPosition) || '';
        console.log('all components:', components);
        console.log('currentComponent: ', this.currentComponent);
        if (!this.currentComponent) {
            console.warn('ButtonComponent: component for code "' + this.code + '" not found.');
            return;
        }
    }
    ngAfterContentInit() {
        var projected = this.el.nativeElement.textContent
            ? this.el.nativeElement.textContent.trim()
            : '';
        this.hasProjectedContent = !!projected;
    }
    get iconPath() {
        return this.currentComponent && this.currentComponent.designIcon
            ? this.componentsService.serverUrl +
                '/design/icon/image?uuid=' +
                this.currentComponent.designIcon.uuid
            : '';
    }
    get buttonStyles() {
        var designColor = this.currentComponent
            ? this.currentComponent.designColor
            : undefined;
        var borderRadius = 'var(--global-border-radius, 3px)';
        var borderWidth = '1px';
        var fontSize = '';
        var fontFamily = '';
        if (this.currentComponent && this.currentComponent.cssConfig) {
            var cssConfig = Object.entries(this.currentComponent.cssConfig);
            borderRadius =
                this.currentComponent.cssConfig['--btn-border-radius'] || borderRadius;
            borderWidth =
                this.currentComponent.cssConfig['--btn-border-width'] || borderWidth;
            fontSize =
                this.currentComponent.cssConfig['--btn-font-size'] || borderWidth;
            fontFamily =
                this.currentComponent.cssConfig['--btn-font-family'] || borderWidth;
        }
        if (this.selected) {
            return {
                'border-radius': borderRadius,
                'border-width': borderWidth,
                'font-size': fontSize,
                'font-family': fontFamily,
                'background-color': designColor ? designColor.fillSelected || '' : '',
                'border-color': designColor ? designColor.borderSelected || '' : '',
                color: designColor ? designColor.textSelected || '' : '',
            };
        }
        if (this.hover) {
            return {
                'border-radius': borderRadius,
                'border-width': borderWidth,
                'font-size': fontSize,
                'font-family': fontFamily,
                'background-color': designColor ? designColor.fillHover || '' : '',
                'border-color': designColor ? designColor.borderHover || '' : '',
                color: designColor ? designColor.textHover || '' : '',
            };
        }
        return {
            'border-radius': borderRadius,
            'border-width': borderWidth,
            'font-size': fontSize,
            'font-family': fontFamily,
            'background-color': designColor ? designColor.fill || '' : '',
            'border-color': designColor ? designColor.border || '' : '',
            color: designColor ? designColor.text || '' : '',
        };
    }
    get iconWrapperStyles() {
        var designColor = this.currentComponent
            ? this.currentComponent.designColor
            : undefined;
        var borderRadius = 'var(--global-border-radius, 3px)';
        if (this.currentComponent && this.currentComponent.cssConfig) {
            var cssConfig = Object.entries(this.currentComponent.cssConfig);
            borderRadius =
                this.currentComponent.cssConfig['--btn-border-radius'] || borderRadius;
        }
        return {
            'background-color': designColor ? designColor.fillHover || '' : '',
            'border-color': designColor ? designColor.borderHover || '' : '',
            color: designColor ? designColor.textHover || '' : '',
            display: 'inline-flex',
            'align-items': 'center',
            'justify-content': 'center',
            'border-radius': borderRadius,
            'margin-right': this.iconPosition === 'left' ? '0px' : '0',
            'margin-left': this.iconPosition === 'right' ? '0px' : '0',
            padding: '4px',
        };
    }
}
ButtonComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: ButtonComponent, deps: [{ token: i1.HttpClient }, { token: DesignComponentsService }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
ButtonComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.0.5", type: ButtonComponent, selector: "style-library-button", inputs: { code: "code" }, ngImport: i0, template: "<button\r\n  type=\"button\"\r\n  class=\"btn-bsi\"\r\n  [ngStyle]=\"buttonStyles\"\r\n  (mouseenter)=\"hover = true\"\r\n  (mouseleave)=\"hover = false\"\r\n>\r\n  <ng-container *ngIf=\"iconExists && iconPosition === 'left'\">\r\n    <span class=\"btn-icon-wrapper\" [ngStyle]=\"iconWrapperStyles\">\r\n      <img [src]=\"iconPath\" class=\"btn-icon\" />\r\n    </span>\r\n  </ng-container>\r\n\r\n  <span [ngClass]=\"[(iconPosition == 'left')?'mr-2':'', (iconPosition == 'right')?'ml-1':'', (iconPosition == null)?'mr-1 ml-1':'']\" class=\"\">\r\n    <ng-content></ng-content>\r\n    <ng-container *ngIf=\"!hasProjectedContent && label\">\r\n      {{ label }}\r\n    </ng-container>\r\n  </span>\r\n\r\n  <ng-container *ngIf=\"iconExists && iconPosition === 'right'\">\r\n    <span class=\"btn-icon-wrapper\" [ngStyle]=\"iconWrapperStyles\">\r\n      <img [src]=\"iconPath\" class=\"btn-icon\" />\r\n    </span>\r\n  </ng-container>\r\n</button>", styles: [".btn-bsi{padding:0;display:inline-flex;align-items:center;vertical-align:top;grid-gap:.5rem;gap:.5rem;font-weight:500;cursor:pointer;transition:all .2s ease-in-out}.btn-bsi .btn-icon{display:block;width:16px;height:16px}\n"], directives: [{ type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: ButtonComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'style-library-button',
                    templateUrl: './button.component.html',
                    styleUrls: ['./button.component.scss'],
                }]
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: DesignComponentsService }, { type: i0.ElementRef }]; }, propDecorators: { code: [{
                type: Input
            }] } });

function loadComponentsFactory(componentsService) {
    return () => componentsService.loadComponents().toPromise();
}
class StyleLibraryModule {
    static forRoot(config) {
        return {
            ngModule: StyleLibraryModule,
            providers: [
                { provide: 'STYLE_LIBRARY_CONFIG', useValue: config },
                DesignComponentsService,
                {
                    provide: APP_INITIALIZER,
                    useFactory: loadComponentsFactory,
                    deps: [DesignComponentsService],
                    multi: true,
                },
            ],
        };
    }
    static forChild() {
        return {
            ngModule: StyleLibraryModule,
        };
    }
}
StyleLibraryModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: StyleLibraryModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
StyleLibraryModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: StyleLibraryModule, declarations: [ButtonComponent], imports: [CommonModule, HttpClientModule], exports: [ButtonComponent] });
StyleLibraryModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: StyleLibraryModule, imports: [[CommonModule, HttpClientModule]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: StyleLibraryModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [ButtonComponent],
                    imports: [CommonModule, HttpClientModule],
                    exports: [ButtonComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ButtonComponent, DesignComponentsService, StyleLibraryModule, loadComponentsFactory };
//# sourceMappingURL=style-library.js.map
