import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DesignComponent } from '../button/model/DesignComponent';
import * as i0 from "@angular/core";
export interface StyleLibraryConfig {
    serverUrl: string;
}
export declare class DesignComponentsService {
    private http;
    private componentsSubject;
    colors$: Observable<DesignComponent[] | null>;
    currentComponents: DesignComponent[] | null;
    serverUrl: string;
    private httpHeaders;
    constructor(http: HttpClient, config?: StyleLibraryConfig);
    loadComponents(): Observable<DesignComponent[]>;
    private initializeDesignComponentSections;
    private applyColor;
    static ɵfac: i0.ɵɵFactoryDeclaration<DesignComponentsService, [null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DesignComponentsService>;
}
