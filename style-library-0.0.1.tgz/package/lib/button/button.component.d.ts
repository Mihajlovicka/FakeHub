import { OnInit, ElementRef, AfterContentInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DesignComponentsService } from './button-color.service';
import { DesignComponent } from './model/DesignComponent';
import * as i0 from "@angular/core";
export declare class ButtonComponent implements OnInit, AfterContentInit {
    private http;
    private componentsService;
    private el;
    code: string;
    color: string;
    label: string;
    iconPosition: string;
    selected: boolean;
    iconExists: boolean;
    hover: boolean;
    hasProjectedContent: boolean;
    currentComponent: DesignComponent | undefined;
    constructor(http: HttpClient, componentsService: DesignComponentsService, el: ElementRef);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    get iconPath(): string;
    get buttonStyles(): {
        [key: string]: string;
    };
    get iconWrapperStyles(): {
        [key: string]: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonComponent, "style-library-button", never, { "code": "code"; }, {}, never, ["*"]>;
}
