export declare class DesignColor {
    id?: number;
    name?: string;
    fill?: string;
    border?: string;
    text?: string;
    fillHover?: string;
    borderHover?: string;
    textHover?: string;
    fillSelected?: string;
    borderSelected?: string;
    textSelected?: string;
}
