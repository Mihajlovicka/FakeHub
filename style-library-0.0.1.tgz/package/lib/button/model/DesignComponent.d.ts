import { DesignColor } from "./DesignColor";
import { DesignComponentGroup } from "./DesignComponentGroup";
import { DesignIcon } from "./DesignIcon";
export declare class DesignComponent {
    id?: number;
    code?: string;
    iconPosition?: string;
    cssConfig?: Record<string, string>;
    designComponentGroup?: DesignComponentGroup;
    designColor?: DesignColor;
    designIcon?: DesignIcon;
}
