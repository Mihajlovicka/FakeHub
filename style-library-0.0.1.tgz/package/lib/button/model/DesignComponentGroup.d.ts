export declare class DesignComponentGroup {
    id?: number;
    name?: string;
}
