export declare class DesignIcon {
    id?: number;
    uuid?: string;
    name?: string;
    description?: string;
}
