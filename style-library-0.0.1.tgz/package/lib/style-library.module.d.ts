import { ModuleWithProviders } from '@angular/core';
import { DesignComponentsService, StyleLibraryConfig } from './button/button-color.service';
import * as i0 from "@angular/core";
import * as i1 from "./button/button.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/common/http";
export declare function loadComponentsFactory(componentsService: DesignComponentsService): () => Promise<import("./button/model/DesignComponent").DesignComponent[]>;
export declare class StyleLibraryModule {
    static forRoot(config: StyleLibraryConfig): ModuleWithProviders<StyleLibraryModule>;
    static forChild(): ModuleWithProviders<StyleLibraryModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StyleLibraryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StyleLibraryModule, [typeof i1.ButtonComponent], [typeof i2.CommonModule, typeof i3.HttpClientModule], [typeof i1.ButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StyleLibraryModule>;
}
